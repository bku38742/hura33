<?php
$id_telegram = "7423204479";
$id_botTele  = "7541158810:AAE0yXDexGnO_Yk80sn-uZsfpVAw8FMlYZQ";
?>