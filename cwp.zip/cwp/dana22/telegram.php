<?php
$id_telegram = "6333663900";
$id_botTele  = "7224629934:AAHh8KTi8rqvFBCY47_wyYW79HlTTWkBYXA";
?>