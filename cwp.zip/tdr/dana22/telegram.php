<?php
$id_telegram = "6320963876";
$id_botTele  = "6902292124:AAHMON69EkZDH3ShhfdCzjONDRWrUnlWNaQ";
?>