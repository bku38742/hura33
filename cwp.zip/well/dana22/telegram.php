<?php
$id_telegram = "6663763778";
$id_botTele  = "7233660113:AAEGtcTDRGSIS85V_w0w3I0hHWEFovWZMgs";
?>