<?php
$id_telegram = "7570654638";
$id_botTele  = "7865204619:AAGjSEYwRCYuDaYXs8Q8z86MREZkRr9XQVw";
?>