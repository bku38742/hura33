<?php
$id_telegram = "6815108057";
$id_botTele  = "7941796571:AAFQYdOgvD0ge8yTRXiLwg13E-jfiKfkmjw";
?>