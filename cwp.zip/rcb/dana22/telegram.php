<?php
$id_telegram = "7485714737";
$id_botTele  = "7145837837:AAHoNNHv9MU8NjtEoihH2mDJr_2vS8_gExg";
?>